# app (unite ui, server, data)

setwd("C:/LUCAS/UFPE/2° PERIODO/Projeto Estatística/BNB-project")

source('global.R')
source('ui.R')
source('server.R')

shinyApp(
  ui = ui,
  server = server
)